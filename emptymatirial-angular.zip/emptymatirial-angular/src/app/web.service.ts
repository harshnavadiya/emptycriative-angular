import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Common } from './module/common';
import { filter, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class WebService {
  action(serviceName: string, parameter: any) {
    return this.http.post<any>(Common.baseUrl + serviceName, parameter).pipe(map(data => data.json())).toPromise();
  }

  logout() {
    localStorage.removeItem('currentUser');
    localStorage.removeItem('userID');
    localStorage.removeItem('auth_token');
    Common.userID = '';
    Common.accessToken = '';
  }
  constructor(private http:HttpClient) { }
}
