import { TestBed } from '@angular/core/testing';

import { SocketMainService } from './socket-main.service';

describe('SocketMainService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SocketMainService = TestBed.get(SocketMainService);
    expect(service).toBeTruthy();
  });
});
