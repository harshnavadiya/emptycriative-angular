import { Component, OnInit } from '@angular/core';
import { SocketMainService } from 'src/app/socket-main.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Common } from 'src/app/module/common';
import { WebService } from 'src/app/web.service';

declare var $:any;
@Component({
  selector: 'app-auth-layout',
  templateUrl: './auth-layout.component.html',
  styleUrls: ['./auth-layout.component.css']
})
export class AuthLayoutComponent implements OnInit {
  
  userName = '';
  password = '';
  returnUrl: string;
  constructor(private socket:SocketMainService, private route: ActivatedRoute,
    private router: Router,private _webService:WebService) { }
  test : Date = new Date();

  checkFullPageBackgroundImage(){
      var $page = $('.full-page');
      var image_src = $page.data('image');

      if(image_src !== undefined){
          var image_container = '<div class="full-page-background" style="background-image: url(' + image_src + ') "/>'
          $page.append(image_container);
      }
  };
  ngOnInit(){
      this.checkFullPageBackgroundImage();

      setTimeout(function(){
          // after 1000 ms we add the class animated to the login/register card
          $('.card').removeClass('card-hidden');
      }, 700)
      this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }

  login() {
    this._webService.action( Common.sv_login, { 'user_name': this.userName, 'password': this.password, 'socket_id': this.socket.sid })
      .then(responseObj => {
        Common.Dlog(responseObj);
        if (responseObj.status === '1') {
          localStorage.setItem('currentUser', JSON.stringify(responseObj.payload));
          localStorage.setItem('userID', JSON.stringify(responseObj.payload.user_id));
          localStorage.setItem('auth_token', JSON.stringify(responseObj.payload.auth_token));

          Common.userID = responseObj.payload.user_id;
          Common.accessToken = responseObj.payload.auth_token;

          this.router.navigate([this.returnUrl]);
        } else {
          // this.openMessage(responseObj.message);
        }
      }).catch(err => Common.Dlog(err));
  }

}
