import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Common } from './module/common';
import * as io from 'socket.io-client';

@Injectable({
  providedIn: 'root'
})
export class SocketMainService {
  public socket = io(Common.socketBaseUrl);
  public sid = '';

  constructor(private router: Router) {
    this.socket.on('connect', () => {
      Common.Dlog('socket connect  ');
      // Common.Dlog(this.socket.id);
      this.sid = this.socket.id;

      if (Common.userID !== '' && Common.userID !== undefined && Common.accessToken !== '') {
        this.socket.emit(Common.sv_update_socket, JSON.stringify({ 'user_id': Common.userID, 'auth_token': Common.accessToken }));
      }

    });

    this.socket.on('disconnect', () => {
      Common.Dlog('socket disconnect');
    });
  }

  emit(service: any, data: any) {
    this.socket.emit(service, data);
  }

  on(service: any, data: any) {
    this.socket.on(service, data);
  }

}
