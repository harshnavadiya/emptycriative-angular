import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Common } from './module/common';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private router: Router) {
  }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    if (localStorage.getItem('userID')) {

      Common.Dlog(localStorage.getItem('userID'));
      return true;
    }

    Common.Dlog(state.url);
    this.router.navigate(['/login'], { queryParams: { retunUrl: state.url } });
    return false;
  }
  
}
