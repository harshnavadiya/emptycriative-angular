import * as moment from 'moment-timezone';
export class Common {
    public static isDev = true;
      public static baseUrl = 'http://localhost:3000/api/';
      public static socketBaseUrl = 'http://localhost:3000';
      public static imageUrl = 'http://localhost:3000/img/';
      public static timeZone = 'Asia/Kolkata';

      // Current User Data
      public static currentUser: any = JSON.parse(localStorage.getItem('currentUser'));
      public static userID: string | null = JSON.parse(localStorage.getItem('userID'));
      public static accessToken: string | null = JSON.parse(localStorage.getItem('auth_token'));

      // Socket
      public static sv_update_socket = 'UpdateSocket';

      // Login Management
      public static sv_login = 'admin/login';

    

      static Dlog(object: any) {
            if (Common.isDev) {
                  console.log(object);
            }
      }

      static dateWithTimezone(date: any, format: string = 'YYYY-MM-DD HH:mm:ss') {

            if (date === '' || date === undefined || date == null) {
                  return '';
            }

            const jun = moment(date);
            jun.tz(Common.timeZone).format();

            let dateString = jun.format(format);
            if (dateString === 'Invalid date') {
                  dateString = '';
            }
            return dateString;
      }

      static stringToDate(date: string) {

            if (date === '' || date === undefined || date === null) {
                  return null;
            }
            return moment(date).toDate();
      }

      static serverToDateString(date: any) {

            if (date === '' || date === undefined || date === null) {
                  return '';
            }

            return moment.tz(date, Common.timeZone).toISOString();
      }
}
export interface DropdownLink {
    title: string;
    iconClass?: string;
    routerLink?: string;
  }
  
  export enum NavItemType {
    Sidebar = 1, // Only ever shown on sidebar
    NavbarLeft = 2, // Left-aligned icon-only link on navbar in desktop mode, shown above sidebar items on collapsed sidebar in mobile mode
    NavbarRight = 3 // Right-aligned link on navbar in desktop mode, shown above sidebar items on collapsed sidebar in mobile mode
  }
  
  export interface NavItem {
    type: NavItemType;
    title: string;
    routerLink?: string;
    iconClass?: string;
    numNotifications?: number;
    dropdownItems?: (DropdownLink | 'separator')[];
  }
